import express from 'express';
import mongoose from 'mongoose';
import 'dotenv/config'
import router from './routes/authroutes.js';
import cors from 'cors'

let app = express();

app.use(express.json());
app.use(cors())

app.listen(process.env.PORT,()=>{
    console.log("Listening on port " + process.env.PORT)
})


mongoose.connect(process.env.MONGODB, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log('MongoDB connection error:', err))

app.use('/auth',router);