import express from 'express';
import { getUser, loginUser, signupUser } from '../controller/authcontroller.js';

const router = express.Router()
router.post('/usersignup', signupUser)
router.post('/userlogin', loginUser)
router.get('/getUsers', getUser)

export default router;