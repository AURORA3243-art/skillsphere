// Fetch and populate content from JSON
fetch('contactus.json')
  .then(response => response.json())
  .then(data => {
    // Update page title
    document.title = data.title;

    // Update header logo and navigation
    const logoImg = document.querySelector('#logo-img');
    logoImg.src = data.header.logo.src;
    logoImg.alt = data.header.logo.alt;

    const nav = document.querySelector('nav');
    data.header.navigation.forEach(item => {
      const link = document.createElement('a');
      link.href = item.link;
      link.textContent = item.text;
      nav.appendChild(link);
    });

    // Update hero section
    document.querySelector('.hero h1').textContent = data.hero.heading;
    document.querySelector('.hero p').textContent = data.hero.description;

    // Update form labels and placeholders
    document.querySelector('label[for="name"]').textContent = data.form.labels.name;
    document.querySelector('#name').placeholder = data.form.placeholders.name;

    document.querySelector('label[for="contact"]').textContent = data.form.labels.contact;
    document.querySelector('#contact').placeholder = data.form.placeholders.contact;

    document.querySelector('label[for="query"]').textContent = data.form.labels.query;
    document.querySelector('#query').placeholder = data.form.placeholders.query;

    document.querySelector('button').textContent = data.form.submitButton;

    // Update footer
    document.querySelector('footer p').textContent = data.footer.copyright;
    document.querySelector('#privacy-link').href = data.footer['privacy-policy-link'];
  })
  .catch(error => console.error('Error loading JSON:', error));

// Form submission (example placeholder functionality)
const form = document.getElementById('contact-form');
form.addEventListener('submit', event => {
  event.preventDefault();
  alert('Form submitted successfully!');
  form.reset();
});
