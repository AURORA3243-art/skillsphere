document.addEventListener('DOMContentLoaded', async function () {
    // Fetch JSON data
    const response = await fetch('course.json');
    const data = await response.json();

    const gridContainer = document.querySelector('.grid-container');
    gridContainer.innerHTML = ''; // Clear any existing content

    // Populate the grid dynamically
    data.courses.forEach(course => {
        const gridItem = document.createElement('div');
        gridItem.className = 'grid-item';
        gridItem.id = course.id;

        gridItem.innerHTML = `
            <a href="${course.link}">
                <img src="${course.image}" alt="${course.name}">
                <div class="text-box">${course.name}</div>
            </a>
        `;

        gridContainer.appendChild(gridItem);
    });

    // Search functionality
    const searchInput = document.querySelector('.search-bar input');
    const searchButton = document.querySelector('.search-bar button');
    searchButton.addEventListener('click', function () {
        const searchTerm = searchInput.value.trim().toLowerCase();
        const found = data.courses.find(course =>
            course.name.toLowerCase().includes(searchTerm)
        );
        if (found) {
            alert(`Found course: ${found.name}`);
        } else {
            alert('Course not found!');
        }
    });
});
