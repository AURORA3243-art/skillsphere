document.addEventListener("DOMContentLoaded", function() {
    const header = document.createElement("header");
    header.style.backgroundColor = "#f39c12";
    header.style.color = "white";
    header.style.padding = "15px";
    header.style.textAlign = "center";

    const h1 = document.createElement("h1");
    h1.textContent = "Object-Oriented Programming in Python";
    header.appendChild(h1);

    const nav = document.createElement("nav");
    const navLinks = [
        { href: "web.html", text: "Home" },
        { href: "contactus.html", text: "Contact Us" },
        { href: "aboutus.html", text: "About Us" },
        { href: "C++.html", text: "C++" },
        { href: "C.html", text: "C" },
        { href: "java.html", text: "Java" },
        { href: "data-science.html", text: "Data Science" },
        { href: "web1.html", text: "Web Development" },
        { href: "app.html", text: "App Development" },
        { href: "python.html", text: "Python Topics" },
        { href: "cyber-security.html", text: "Cyber Security" }
    ];

    navLinks.forEach(link => {
        const a = document.createElement("a");
        a.href = link.href;
        a.textContent = link.text;
        a.style.textDecoration = "none";
        a.style.margin = "0 15px";
        a.style.color = "white";
        a.style.fontWeight = "bold";
        nav.appendChild(a);
    });

    header.appendChild(nav);
    document.body.appendChild(header);

    const main = document.createElement("main");
    main.style.textAlign = "center";
    main.style.padding = "50px 0";
    main.style.margin = "20px";
    main.style.borderRadius = "10px";

    const content = document.createElement("div");
    content.style.maxWidth = "800px";
    content.style.margin = "0 auto";
    content.style.backgroundColor = "#fff";
    content.style.padding = "30px";
    content.style.borderRadius = "10px";
    content.style.boxShadow = "0 4px 10px rgba(0, 0, 0, 0.1)";

    // Introduction Section
    const intro = document.createElement("p");
    intro.textContent = "Object-Oriented Programming (OOP) is a powerful paradigm in Python, enabling developers to write modular, reusable, and efficient code.";
    intro.style.fontSize = "1.2em";
    intro.style.marginBottom = "20px";
    content.appendChild(intro);

    const h2 = document.createElement("h2");
    h2.textContent = "Understanding Object-Oriented Programming (OOP)";
    h2.style.color = "#fdcb6e";
    h2.style.fontSize = "2em";
    h2.style.marginBottom = "20px";
    content.appendChild(h2);

    const p1 = document.createElement("p");
    p1.innerHTML = '<span class="highlight">Object-Oriented Programming</span> is a programming paradigm based on the concept of "objects", which can contain data and code. Python supports OOP through:';
    p1.style.fontSize = "1.1em";
    p1.style.lineHeight = "1.8";
    p1.style.color = "#4a4a4a";
    content.appendChild(p1);

    const ul1 = document.createElement("ul");
    ul1.style.marginLeft = "40px";
    ul1.style.listStyleType = "disc";
    const listItems = [
        { text: "Classes: Blueprints for creating objects." },
        { text: "Objects: Instances of classes." },
        { text: "Inheritance: Mechanism to create a new class using properties of an existing class." },
        { text: "Encapsulation: Hiding the internal state of an object and requiring all interaction to be performed through an object's methods." }
    ];

    listItems.forEach(item => {
        const li = document.createElement("li");
        li.style.margin = "10px 0";
        li.textContent = item.text;
        ul1.appendChild(li);
    });
    content.appendChild(ul1);

    // Advantages Section
    const advantages = document.createElement("h3");
    advantages.textContent = "Advantages of OOP:";
    advantages.style.color = "#3498db";
    advantages.style.marginTop = "20px";
    content.appendChild(advantages);

    const advList = document.createElement("ul");
    const advItems = [
        "Modularity: Code is organized into classes.",
        "Reusability: Classes and methods can be reused.",
        "Scalability: Easy to add new features."
    ];

    advItems.forEach(text => {
        const li = document.createElement("li");
        li.textContent = text;
        advList.appendChild(li);
    });
    content.appendChild(advList);

    // Code Example Section
    const codeTitle = document.createElement("h3");
    codeTitle.textContent = "Code Example:";
    codeTitle.style.color = "#2ecc71";
    codeTitle.style.marginTop = "20px";
    content.appendChild(codeTitle);

    const codeBlock = document.createElement("pre");
    codeBlock.style.backgroundColor = "#f4f4f4";
    codeBlock.style.padding = "10px";
    codeBlock.style.borderRadius = "5px";
    codeBlock.style.overflowX = "auto";
    codeBlock.textContent = `class Animal:
    def __init__(self, name):
        self.name = name
    
    def speak(self):
        return f"{self.name} makes a sound"

# Creating an object
dog = Animal("Dog")
print(dog.speak())`;
    content.appendChild(codeBlock);

    // Extra Resources Section
    const resources = document.createElement("h3");
    resources.textContent = "Extra Resources:";
    resources.style.color = "#9b59b6";
    resources.style.marginTop = "20px";
    content.appendChild(resources);

    const ul2 = document.createElement("ul");
    const links = [
        { href: "https://realpython.com/python3-object-oriented-programming/", text: "Real Python: OOP in Python" },
        { href: "https://docs.python.org/3/tutorial/classes.html", text: "Python Classes Documentation" }
    ];

    links.forEach(link => {
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = link.href;
        a.target = "_blank";
        a.textContent = link.text;
        a.style.textDecoration = "none";
        a.style.color = "#8e44ad";
        a.style.fontWeight = "bold";
        li.appendChild(a);
        ul2.appendChild(li);
    });
    content.appendChild(ul2);

    main.appendChild(content);
    document.body.appendChild(main);

    const footer = document.createElement("footer");
    footer.style.backgroundColor = "#f39c12";
    footer.style.color = "white";
    footer.style.padding = "15px";
    footer.style.textAlign = "center";
    footer.style.position = "fixed";
    footer.style.width = "100%";
    footer.style.bottom = "0";
    document.body.appendChild(footer);
});
