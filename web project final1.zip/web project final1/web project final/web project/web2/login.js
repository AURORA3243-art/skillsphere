const loginForm = document.getElementById('loginForm');

// Handle form submission
loginForm.addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent default form submission

    // Get user input
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Send data to backend
    try {
        const response = await fetch('http://localhost:5000/auth/userlogin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: username, password })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            // Save token in local storage
            localStorage.setItem('token', result.token);

            // Redirect to web.html
            window.location.href = './web.html';
        } else {
            alert(result.error || 'Login failed. Please try again.');
        }
    } catch (error) {
        console.error('Error logging in:', error);
        alert('Something went wrong. Please try again later.');
    }
});
