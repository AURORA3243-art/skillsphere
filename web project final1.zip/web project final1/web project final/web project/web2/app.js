function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}

function createGridItems() {
    const topics = [
        { text: 'Introduction to App Development', link: 'app_intro.html' },
        { text: 'Android Development', link: 'app_android.html' },
        { text: 'iOS Development', link: 'app_ios.html' },
        { text: 'Cross-Platform Development', link: 'app_cross.html' },
        { text: 'Flutter', link: 'app_flutter.html' },
        { text: 'React Native', link: 'app_react.html' },
        { text: 'App Security', link: 'app_security.html' }
    ];

    const gridContainer = document.getElementById('gridContainer');
    
    topics.forEach((topic, index) => {
        const gridItem = document.createElement('div');
        gridItem.classList.add('grid-item');
        gridItem.classList.add(`topic${index + 1}`);

        const link = document.createElement('a');
        link.href = topic.link;
        link.textContent = topic.text;

        gridItem.appendChild(link);
        gridContainer.appendChild(gridItem);
    });
}

function initPage() {
    const header = document.createElement('header');
    const toggleButton = document.createElement('button');
    toggleButton.textContent = 'Toggle Dark Mode';
    toggleButton.classList.add('toggle-button');
    toggleButton.addEventListener('click', toggleDarkMode);

    header.appendChild(toggleButton);
    document.body.appendChild(header);

    createGridItems();
}

window.onload = function() {
    initPage();
};
