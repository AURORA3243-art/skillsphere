document.addEventListener("DOMContentLoaded", function() {

    const header = document.createElement("header");
    const nav = document.createElement("nav");
    const navLinks = [
        { href: "web.html", text: "Home" },
        { href: "contactus.html", text: "Contact Us" },
        { href: "aboutus.html", text: "About Us" },
        { href: "c++.html", text: "C++" },
        { href: "c.html", text: "C" },
        { href: "data-science.html", text: "Data Science" },
        { href: "app.html", text: "App" },
        { href: "python.html", text: "Python" },
        { href: "cyber-security.html", text: "Cyber Security" },
        { href: "web1.html", text: "Web Development" }
    ];

    navLinks.forEach(link => {
        const a = document.createElement("a");
        document.addEventListener("DOMContentLoaded", function() {
            const header = document.createElement("header");
            const nav = document.createElement("nav");
            const navLinks = [
                { href: "web.html", text: "Home" },
                { href: "contactus.html", text: "Contact Us" },
                { href: "aboutus.html", text: "About Us" },
                { href: "c++.html", text: "C++" },
                { href: "c.html", text: "C" },
                { href: "data-science.html", text: "Data Science" },
                { href: "app.html", text: "App" },
                { href: "python.html", text: "Python" },
                { href: "cyber-security.html", text: "Cyber Security" },
                { href: "web1.html", text: "Web Development" }
            ];
        
            navLinks.forEach(link => {
                const a = document.createElement("a");
                a.href = link.href;
                a.textContent = link.text;
                nav.appendChild(a);
            });
        
            header.appendChild(nav);
            document.body.appendChild(header);
        
            // Create Main Content
            const main = document.createElement("main");
        
            const h1 = document.createElement("h1");
            h1.textContent = "Python Topics";
            main.appendChild(h1);
        
            const gridContainer = document.createElement("div");
            gridContainer.classList.add("grid-container");
        
            const topics = [
                { link: "python_intro.html", text: "Introduction to Python", className: "topic1" },
                { link: "python_datatypes.html", text: "Data Types and Variables", className: "topic2" },
                { link: "python_control.html", text: "Control Structures", className: "topic3" },
                { link: "python_functions.html", text: "Functions and Modules", className: "topic4" },
                { link: "python_oops.html", text: "Object-Oriented Programming", className: "topic5" },
                { link: "python_libraries.html", text: "Libraries (NumPy, Pandas)", className: "topic6" },
                { link: "python_advance.html", text: "Advanced Python Topics", className: "topic7" }
            ];
        
            topics.forEach(topic => {
                const gridItem = document.createElement("div");
                gridItem.classList.add("grid-item", topic.className);
                const a = document.createElement("a");
                a.href = topic.link;
                a.textContent = topic.text;
                gridItem.appendChild(a);
                gridContainer.appendChild(gridItem);
            });
        
            main.appendChild(gridContainer);
        
            // References Section
            const references = document.createElement("div");
            references.classList.add("references");
        
            const h3 = document.createElement("h3");
            h3.textContent = "References";
            references.appendChild(h3);
        
            const table = document.createElement("table");
            const resources = [
                { resource: "Official Python Documentation", link: "https://docs.python.org/3/" },
                { resource: "W3Schools Python Tutorial", link: "https://www.w3schools.com/python/" },
                { resource: "Real Python", link: "https://realpython.com/" }
            ];
        
            resources.forEach(resource => {
                const tr = document.createElement("tr");
                const td1 = document.createElement("td");
                td1.textContent = resource.resource;
                const td2 = document.createElement("td");
                const a = document.createElement("a");
                a.href = resource.link;
                a.textContent = resource.link;
                td2.appendChild(a);
                tr.appendChild(td1);
                tr.appendChild(td2);
                table.appendChild(tr);
            });
        
            references.appendChild(table);
            main.appendChild(references);
        
            document.body.appendChild(main);
        });
            a.href = link.href;
        a.textContent = link.text;
        nav.appendChild(a);
    });

    header.appendChild(nav);
    document.body.appendChild(header);

    const main = document.createElement("main");

    const h1 = document.createElement("h1");
    h1.textContent = "Python Topics";
    main.appendChild(h1);

    const gridContainer = document.createElement("div");
    gridContainer.classList.add("grid-container");

    const topics = [
        { link: "python_intro.html", text: "Introduction to Python", className: "topic1" },
        { link: "python_datatypes.html", text: "Data Types and Variables", className: "topic2" },
        { link: "python_control.html", text: "Control Structures", className: "topic3" },
        { link: "python_functions.html", text: "Functions and Modules", className: "topic4" },
        { link: "python_oops.html", text: "Object-Oriented Programming", className: "topic5" },
        { link: "python_libries.html", text: "Libraries (NumPy, Pandas)", className: "topic6" },
        { link: "python_advance.html", text: "Advanced Python Topics", className: "topic7" }
    ];

    topics.forEach(topic => {
        const gridItem = document.createElement("div");
        gridItem.classList.add("grid-item", topic.className);
        const a = document.createElement("a");
        a.href = topic.link;
        a.textContent = topic.text;
        gridItem.appendChild(a);
        gridContainer.appendChild(gridItem);
    });

    main.appendChild(gridContainer);

    const references = document.createElement("div");
    references.classList.add("references");

    const h3 = document.createElement("h3");
    h3.textContent = "References";
    references.appendChild(h3);

    const table = document.createElement("table");

    const resources = [
        { resource: "Official Python Documentation", link: "https://docs.python.org/3/" },
        { resource: "W3Schools Python Tutorial", link: "https://www.w3schools.com/python/" },
        { resource: "Real Python", link: "https://realpython.com/" }
    ];

    resources.forEach(resource => {
        const tr = document.createElement("tr");
        const td1 = document.createElement("td");
        td1.textContent = resource.resource;
        const td2 = document.createElement("td");
        const a = document.createElement("a");
        a.href = resource.link;
        a.textContent = resource.link;
        td2.appendChild(a);
        tr.appendChild(td1);
        tr.appendChild(td2);
        table.appendChild(tr);
    });

    references.appendChild(table);
    main.appendChild(references);
    
    document.body.appendChild(main);
});
