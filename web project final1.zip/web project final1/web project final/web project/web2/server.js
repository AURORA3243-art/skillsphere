// server.js
const fs = require('fs');
const express = require('express');
const app = express();
const path = 'C:/web html/web project/contactData.json';

app.use(express.json());

// Save contact data to JSON file
app.post('/save-contact', (req, res) => {
    const data = req.body;
    fs.appendFileSync(path, JSON.stringify(data) + '\n');
    res.send({ message: 'Data saved successfully!' });
});

// Retrieve contact data from JSON file
app.get('/get-contact', (req, res) => {
    try {
        const data = fs.readFileSync(path, 'utf8').trim().split('\n').map(line => JSON.parse(line));
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Could not retrieve data' });
    }
});

app.listen(3000, () => console.log('Server started on http://localhost:3000'));
