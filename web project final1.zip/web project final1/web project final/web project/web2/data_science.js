document.addEventListener("DOMContentLoaded", function () {
    const body = document.body;

    // Create header with navigation
    const header = document.createElement('header');
    const nav = document.createElement('nav');
    
    const navLinks = [
        { href: "web.html", text: "Home" },
        { href: "contactus.html", text: "Contact Us" },
        { href: "aboutus.html", text: "About Us" },
        { href: "c++.html", text: "C++" },
        { href: "java.html", text: "Java" },
        { href: "python.html", text: "Python" },
        { href: "app.html", text: "App Development" },
        { href: "web1.html", text: "Web Development" },
        { href: "cyber-security.html", text: "Cyber Security" }
    ];

    navLinks.forEach(link => {
        const a = document.createElement('a');
        a.href = link.href;
        a.textContent = link.text;
        nav.appendChild(a);
    });

    header.appendChild(nav);
    body.appendChild(header);

    // Main content
    const main = document.createElement('main');
    
    const mainHeading = document.createElement('h1');
    mainHeading.textContent = "Data Science Topics";
    main.appendChild(mainHeading);

    const gridContainer = document.createElement('div');
    gridContainer.classList.add('grid-container');

    const topics = [
        { class: "topic1", href: "data_science_intro.html", text: "Introduction to Data Science" },
        { class: "topic2", href: "data_science_analysis.html", text: "Data Analysis" },
        { class: "topic3", href: "data_science_machine.html", text: "Machine Learning" },
        { class: "topic4", href: "data_science-data.html", text: "Data Visualization" },
        { class: "topic5", href: "data_science_big.html", text: "Big Data Technologies" },
        { class: "topic6", href: "data_science_tool.html", text: "Data Science Tools" },
        { class: "topic7", href: "data_science_stat.html", text: "Statistics for Data Science" }
    ];

    topics.forEach(topic => {
        const gridItem = document.createElement('div');
        gridItem.className = `grid-item ${topic.class}`;

        const a = document.createElement('a');
        a.href = topic.href;
        a.textContent = topic.text;

        gridItem.appendChild(a);
        gridContainer.appendChild(gridItem);
    });

    main.appendChild(gridContainer);

    // References section
    const references = document.createElement('div');
    references.classList.add('references');

    const referencesHeading = document.createElement('h3');
    referencesHeading.textContent = "References";
    references.appendChild(referencesHeading);

    const table = document.createElement('table');

    const resources = [
        { resource: "Coursera Data Science", link: "https://www.coursera.org/specializations/jhu-data-science" },
        { resource: "DataCamp", link: "https://www.datacamp.com/" },
        { resource: "Kaggle", link: "https://www.kaggle.com/" }
    ];

    resources.forEach(resource => {
        const row = document.createElement('tr');

        const resourceCell = document.createElement('td');
        resourceCell.textContent = resource.resource;
        row.appendChild(resourceCell);

        const linkCell = document.createElement('td');
        const a = document.createElement('a');
        a.href = resource.link;
        a.textContent = resource.link;
        a.target = "_blank"; // Opens link in a new tab
        linkCell.appendChild(a);
        row.appendChild(linkCell);

        table.appendChild(row);
    });

    references.appendChild(table);
    main.appendChild(references);

    body.appendChild(main);

    // Styles
    const style = document.createElement('style');
    style.textContent = `
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            background: url('your-background-image.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #2d6187;
            border-bottom: 2px solid #d9d3cd;
        }

        nav a {
            text-decoration: none;
            margin: 0 15px;
            color: #ddd;
            font-weight: bold;
        }

        main {
            text-align: center;
            padding: 50px 0;
            background-color: rgba(255, 255, 255, 0.9);
            margin: 20px;
            border-radius: 10px;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            max-width: 800px;
            margin: 0 auto;
        }

        .grid-item {
            padding: 20px;
            border-radius: 20px;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            color: white;
        }

        .grid-item a {
            text-decoration: none;
            color: white;
        }

        .grid-item:hover {
            transform: scale(1.05);
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.2);
        }

        .topic1 { background-color: #3f51b5; }
        .topic2 { background-color: #673ab7; }
        .topic3 { background-color: #009688; }
        .topic4 { background-color: #ff9800; }
        .topic5 { background-color: #ff5722; }
        .topic6 { background-color: #8bc34a; }
        .topic7 { background-color: #ffc107; }

        .references {
            margin-top: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
        }

        .references h3 {
            color: #4a2c2a;
            font-size: 1.5em;
            text-decoration: underline;
        }

        .references table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .references th, .references td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .references th {
            background-color: #3f51b5;
            color: white;
        }

        .references td {
            background-color: #fafafa;
        }

        .references a {
            text-decoration: none;
            color: #1e90ff;
            font-weight: bold;
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            border-top: 2px solid #d9d3cd;
        }

        footer a {
            text-decoration: none;
            margin: 0 10px;
            color: #333;
            font-weight: bold;
        }
    `;
    document.head.appendChild(style);
});
