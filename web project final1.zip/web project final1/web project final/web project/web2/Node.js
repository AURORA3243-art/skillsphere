const fs = require('fs');
const express = require('express');
const app = express();
const path = 'C:/web html/web project/contactData.json';

app.use(express.json());

app.post('/save-contact', (req, res) => {
    const data = req.body;
    fs.appendFileSync(path, JSON.stringify(data) + '\n');
    res.send({ message: 'Data saved successfully!' });
});

app.listen(3000, () => console.log('Server started on http://localhost:3000'));
