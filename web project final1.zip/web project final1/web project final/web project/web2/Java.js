
document.addEventListener('DOMContentLoaded', function() {
    const style = document.createElement('style');
    style.innerHTML =
    document.head.appendChild(style);

    const header = document.createElement('header');
    const nav = document.createElement('nav');
    const navLinks = [
        'Home', 'Contact Us', 'About Us', 'C++', 'C', 'Data Science', 
        'App', 'Python', 'Cyber Security', 'Web Development'
    ];
    navLinks.forEach(linkText => {
        const link = document.createElement('a');
        link.href = linkText.toLowerCase().replace(/\s+/g, '') + '.html';
        link.innerText = linkText;
        nav.appendChild(link);
    });
    header.appendChild(nav);
    document.body.appendChild(header);

    const main = document.createElement('main');
    const heading = document.createElement('h1');
    heading.innerText = 'Java Topics';
    main.appendChild(heading);

    const gridContainer = document.createElement('div');
    gridContainer.classList.add('grid-container');
    const topics = [
        {name: 'Introduction to Java', link: 'java_intro.html', class: 'topic1'},
        {name: 'Variables and Data Types', link: 'java_data.html', class: 'topic2'},
        {name: 'Control Structures', link: 'java_control.html', class: 'topic3'},
        {name: 'Methods and Functions', link: 'java_method.html', class: 'topic4'},
        {name: 'Object-Oriented Programming', link: 'java_oop.html', class: 'topic5'},
        {name: 'Collections Framework', link: 'java_collection.html', class: 'topic6'},
        {name: 'Exception Handling', link: 'java_exception.html', class: 'topic7'}
    ];

    topics.forEach(topic => {
        const gridItem = document.createElement('div');
        gridItem.classList.add('grid-item', topic.class);
        const link = document.createElement('a');
        link.href = topic.link;
        link.innerText = topic.name;
        gridItem.appendChild(link);
        gridContainer.appendChild(gridItem);
    });

    main.appendChild(gridContainer);

    const references = document.createElement('div');
    references.classList.add('references');
    const referencesTitle = document.createElement('h3');
    referencesTitle.innerText = 'References';
    references.appendChild(referencesTitle);

    const table = document.createElement('table');
    const headerRow = document.createElement('tr');
    const resourceHeader = document.createElement('th');
    resourceHeader.innerText = 'Resource';
    const linkHeader = document.createElement('th');
    linkHeader.innerText = 'Link';
    headerRow.appendChild(resourceHeader);
    headerRow.appendChild(linkHeader);
    table.appendChild(headerRow);

    const resources = [
        {name: 'Learn Java', link: 'https://www.learnjavaonline.org/'},
        {name: 'Java Programming', link: 'https://www.javatpoint.com/java-tutorial'},
        {name: 'GeeksforGeeks Java', link: 'https://www.geeksforgeeks.org/java-tutorial/'}
    ];

    resources.forEach(resource => {
        const row = document.createElement('tr');
        const resourceCell = document.createElement('td');
        resourceCell.innerText = resource.name;
        const linkCell = document.createElement('td');
        const anchor = document.createElement('a');
        anchor.href = resource.link;
        anchor.innerText = 'Visit';
        linkCell.appendChild(anchor);
        row.appendChild(resourceCell);
        row.appendChild(linkCell);
        table.appendChild(row);
    });

    references.appendChild(table);
    main.appendChild(references);

    document.body.appendChild(main);
});
