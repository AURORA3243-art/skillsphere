// Fetch JSON data and dynamically populate content
fetch('aboutus.json')
  .then(response => response.json())
  .then(data => {
    // Update title
    document.title = data.title;

    // Update logo
    const logoImg = document.querySelector('#logo-img');
    logoImg.src = data.header.logo.src;
    logoImg.alt = data.header.logo.alt;

    // Update navigation links
    const nav = document.querySelector('#nav-links');
    data.header.navigation.forEach(item => {
      const link = document.createElement('a');
      link.href = item.link;
      link.textContent = item.text;
      nav.appendChild(link);
    });

    // Update hero section
    document.querySelector('#hero-heading').textContent = data.hero.heading;
    document.querySelector('#hero-description').textContent = data.hero.description;

    // Update about section
    document.querySelector('#about-heading').textContent = data.about.heading;
    document.querySelector('#about-content').textContent = data.about.content;

    // Dynamically add team members
    const teamMembersDiv = document.querySelector('#team-members');
    data.about.team.forEach(member => {
      const teamMemberDiv = document.createElement('div');
      teamMemberDiv.classList.add('team-member');
      teamMemberDiv.innerHTML = `
        <img src="${member.image.src}" alt="${member.image.alt}" class="team-photo">
        <p>${member.name}</p>
      `;
      teamMembersDiv.appendChild(teamMemberDiv);
    });

    // Update vision section
    document.querySelector('#vision-heading').textContent = data.vision.heading;
    document.querySelector('#vision-content').textContent = data.vision.content;

    // Update footer
    document.querySelector('#footer-copyright').textContent = data.footer.copyright;
    const privacyLink = document.querySelector('#privacy-policy-link');
    privacyLink.href = data.footer['privacy-policy-link'];
  })
  .catch(error => console.error('Error loading JSON data:', error));
