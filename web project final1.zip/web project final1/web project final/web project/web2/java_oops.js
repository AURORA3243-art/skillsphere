document.addEventListener("DOMContentLoaded", function() {
    
    const header = document.createElement("header");
    header.style.backgroundColor = "#dbc926";
    header.style.color = "white";
    header.style.padding = "15px";
    header.style.textAlign = "center";

    const h1 = document.createElement("h1");
    h1.textContent = "Object-Oriented Programming in Java";
    header.appendChild(h1);

    const nav = document.createElement("nav");
    const navLinks = [
        { href: "web.html", text: "Home" },
        { href: "contactus.html", text: "Contact Us" },
        { href: "aboutus.html", text: "About Us" },
        { href: "C++.html", text: "C++" },
        { href: "C.html", text: "C" },
        { href: "java.html", text: "Java Topics" },
        { href: "data-science.html", text: "Data Science" },
        { href: "web1.html", text: "Web Development" },
        { href: "app.html", text: "App Development" },
        { href: "python.html", text: "Python" },
        { href: "cyber-security.html", text: "Cyber Security" }
    ];

    navLinks.forEach(link => {
        const a = document.createElement("a");
        a.href = link.href;
        a.textContent = link.text;
        a.style.textDecoration = "none";
        a.style.margin = "0 15px";
        a.style.color = "white";
        a.style.fontWeight = "bold";
        nav.appendChild(a);
    });

    header.appendChild(nav);
    document.body.appendChild(header);

    const main = document.createElement("main");
    main.style.textAlign = "center";
    main.style.padding = "50px 0";
    main.style.margin = "20px";
    main.style.borderRadius = "10px";

    const content = document.createElement("div");
    content.style.maxWidth = "800px";
    content.style.margin = "0 auto";
    content.style.backgroundColor = "#fff";
    content.style.padding = "30px";
    content.style.borderRadius = "10px";
    content.style.boxShadow = "0 4px 10px rgba(0, 0, 0, 0.1)";

    const h2 = document.createElement("h2");
    h2.textContent = "Understanding Object-Oriented Programming (OOP) in Java";
    h2.style.color = "#fdcb6e";
    h2.style.fontSize = "2em";
    h2.style.marginBottom = "20px";
    content.appendChild(h2);

    const p1 = document.createElement("p");
    p1.innerHTML = '<span class="highlight">Object-Oriented Programming (OOP)</span> is a programming paradigm based on the concept of "objects", which can contain data in the form of fields (often known as attributes or properties) and code in the form of procedures (often known as methods).';
    p1.style.fontSize = "1.1em";
    p1.style.lineHeight = "1.8";
    p1.style.color = "#4a4a4a";
    content.appendChild(p1);

    const p2 = document.createElement("p");
    p2.textContent = "Java is a powerful, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible. It is widely used for building enterprise-scale applications, web applications, mobile applications, and more.";
    content.appendChild(p2);

    const h3_1 = document.createElement("h3");
    h3_1.textContent = "Key Concepts of OOP in Java:";
    content.appendChild(h3_1);

    const ul1 = document.createElement("ul");
    ul1.style.marginLeft = "40px";
    ul1.style.listStyleType = "disc";
    const listItems1 = [
        { text: "Encapsulation: The bundling of data (attributes) and methods (functions) that operate on the data into a single unit, or class. It restricts direct access to some of the object's components." },
        { text: "Inheritance: A mechanism where a new class inherits properties and behavior (methods) from an existing class. This promotes code reuse and establishes a relationship between classes." },
        { text: "Polymorphism: The ability of a single function or method to work in different ways based on the context. In Java, this is primarily achieved through method overriding and overloading." },
        { text: "Abstraction: The concept of hiding the complex reality while exposing only the necessary parts. It allows the implementation of complex systems to be simplified for users." }
    ];

    listItems1.forEach(item => {
        const li = document.createElement("li");
        li.style.margin = "10px 0";
        li.textContent = item.text;
        ul1.appendChild(li);
    });
    content.appendChild(ul1);

    const h3_2 = document.createElement("h3");
    h3_2.textContent = "Advantages of OOP in Java:";
    content.appendChild(h3_2);

    const ul2 = document.createElement("ul");
    const listItems2 = [
        "Improved code organization and modularity.",
        "Reusability through inheritance.",
        "Enhanced maintainability and flexibility.",
        "Better data security and encapsulation."
    ];

    listItems2.forEach(item => {
        const li = document.createElement("li");
        li.style.margin = "10px 0";
        li.textContent = item;
        ul2.appendChild(li);
    });
    content.appendChild(ul2);

    const h3_3 = document.createElement("h3");
    h3_3.textContent = "Example Code:";
    content.appendChild(h3_3);

    const pre = document.createElement("pre");
    const code = document.createElement("code");
    code.textContent = `
public class Animal {
    void sound() {
        System.out.println("Animal makes a sound");
    }
}

public class Dog extends Animal {
    void sound() {
        System.out.println("Dog barks");
    }
}

public class TestPolymorphism {
    public static void main(String[] args) {
        Animal myDog = new Dog();
        myDog.sound(); // Output: Dog barks
    }
}
    `;
    pre.appendChild(code);
    content.appendChild(pre);

    const p3 = document.createElement("p");
    p3.textContent = "For more information on Object-Oriented Programming in Java, visit:";
    content.appendChild(p3);

    const ul3 = document.createElement("ul");
    const links = [
        { href: "https://www.oracle.com/java/technologies/javase/oop.html", text: "Oracle OOP Concepts in Java" },
        { href: "https://www.javatpoint.com/java-oops-concepts", text: "Java OOP Concepts - Javatpoint" },
        { href: "https://www.geeksforgeeks.org/object-oriented-programming-oops-concept-in-java/", text: "GeeksforGeeks OOPs Concepts in Java" }
    ];

    links.forEach(link => {
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = link.href;
        a.target = "_blank";
        a.textContent = link.text;
        a.style.textDecoration = "none";
        a.style.color = "#0984e3";
        a.style.fontWeight = "bold";
        li.appendChild(a);
        ul3.appendChild(li);
    });
    content.appendChild(ul3);

    main.appendChild(content);
    document.body.appendChild(main);

    const footer = document.createElement("footer");
    footer.style.backgroundColor = "#dbc926";
    footer.style.color = "white";
    footer.style.padding = "15px";
    footer.style.textAlign = "center";
    footer.style.position = "fixed";
    footer.style.width = "100%";
    footer.style.bottom = "0";

    const footerLinks = [
        { href: "web.html", text: "Home" },
        { href: "contactus.html", text: "Contact Us" },
        { href: "aboutus.html", text: "About Us" }
    ];

    footerLinks.forEach(link => {
        const a = document.createElement("a");
        a.href = link.href;
        a.textContent = link.text;
        a.style.textDecoration = "none";
        a.style.margin = "0 15px";
        a.style.color = "white";
        a.style.fontWeight = "bold";
        footer.appendChild(a);
    });

    document.body.appendChild(footer);
});
document.addEventListener("DOMContentLoaded", function() {
    console.log("DOM is fully loaded and parsed");
});
