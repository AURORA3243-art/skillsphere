function createGridItems() {
    const topics = [
        { text: 'Introduction to C', link: 'c_intro.html' },
        { text: 'Variables and Data Types', link: 'C_data.html' },
        { text: 'Control Structures', link: 'c_control.html' },
        { text: 'Functions', link: 'c_function.html' },
        { text: 'Pointers', link: 'c_pointers.html' },
        { text: 'Arrays', link: 'c_arrays.html' },
        { text: 'Advanced Topics', link: 'c_advance.html' }
    ];

    const gridContainer = document.getElementById('grid-container');
    gridContainer.innerHTML = '';  // Clear existing content

    topics.forEach(topic => {
        const gridItem = document.createElement('div');
        gridItem.classList.add('grid-item');
        gridItem.innerHTML = `<a href="${topic.link}">${topic.text}</a>`;

        gridContainer.appendChild(gridItem);
    });
}

function createReferences() {
    const references = [
        { name: 'Learn C', url: 'https://www.learn-c.org/' },
        { name: 'GeeksforGeeks C', url: 'https://www.geeksforgeeks.org/c-programming-language/' }
    ];

    const referencesDiv = document.getElementById('references');
    referencesDiv.innerHTML = '';  // Clear existing content

    const referencesTitle = document.createElement('h3');
    referencesTitle.textContent = 'References';
    referencesDiv.appendChild(referencesTitle);

    const table = document.createElement('table');
    const headerRow = document.createElement('tr');
    headerRow.innerHTML = '<th>Resource</th><th>Link</th>';
    table.appendChild(headerRow);

    references.forEach(ref => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${ref.name}</td><td><a href="${ref.url}" target="_blank">${ref.url}</a></td>`;
        table.appendChild(row);
    });

    referencesDiv.appendChild(table);
}

window.onload = function() {
    createGridItems();
    createReferences();
};
