// Search Bar Functionality
const searchButton = document.querySelector('.search-bar button');
const searchInput = document.querySelector('.search-bar input');

searchButton.addEventListener('click', () => {
    const searchTerm = searchInput.value.trim();
    if (searchTerm) {
        alert(`Searching for: ${searchTerm}`);
    } else {
        alert('Please enter a search term.');
    }
});

// Fetch JSON data and update page content
fetch('web.json')
  .then(response => response.json())
  .then(data => {
    // Set the page title dynamically
    document.title = data.title;

    // Populate header navigation dynamically
    const nav = document.querySelector('nav');
    data.header.navigation.forEach(item => {
      const link = document.createElement('a');
      link.href = item.link;
      link.textContent = item.text;
      if (item.class) link.classList.add(item.class);
      nav.appendChild(link);
    });

    // Update hero section heading
    const heroHeading = document.querySelector('.hero h1');
    heroHeading.textContent = data.hero.heading;

    // Update CTA text and button
    const ctaText = document.querySelector('.cta p');
    ctaText.textContent = data.cta.text;
    const ctaButton = document.querySelector('.cta .explore-button');
    ctaButton.textContent = data.cta.button.text;
    ctaButton.onclick = () => window.location.href = data.cta.button.link;

    // Update footer copyright and privacy policy link
    const footer = document.querySelector('footer');
    footer.querySelector('p').innerHTML = data.footer.copyright;
    const privacyLink = footer.querySelector('a');
    privacyLink.href = data.footer['privacy-policy-link'];
  })
  .catch(error => console.error('Error loading JSON:', error));
