document.addEventListener("DOMContentLoaded", function () {
    fetchTopics();
});

function fetchTopics() {
    fetch('C++.json') // Fetching the JSON file
        .then(response => {
            if (!response.ok) {
                throw new Error("Network response was not ok " + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            displayTopics(data);
        })
        .catch(error => {
            console.error("Error loading topics:", error);
            const container = document.getElementById("topics-container");
            container.innerHTML = "<p>Failed to load topics. Please try again later.</p>";
        });
}

function displayTopics(data) {
    const container = document.getElementById("topics-container");

    // Clear previous content
    container.innerHTML = '<h1>C++ Topics</h1>';

    data.topics.forEach(topic => {
        const topicElement = document.createElement("a");
        topicElement.href = topic.link;
        topicElement.textContent = topic.text;
        topicElement.style.display = "block";
        topicElement.style.margin = "10px";
        topicElement.style.textDecoration = "none";
        topicElement.style.color = "#1a4d63";
        topicElement.style.fontSize = "18px";
        
        container.appendChild(topicElement);
    });
}
