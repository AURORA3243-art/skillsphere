document.getElementById("signupForm").addEventListener("submit", async function (event) {
    event.preventDefault();
  
    // Collect form data
    const formData = new FormData(event.target);
    const userData = {};
    formData.forEach((value, key) => {
      userData[key] = value;
    });
  
    try {
      // Send data to backend
      const response = await fetch("http://localhost:5000/auth/usersignup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      });
  
      const result = await response.json();
  
      if (response.ok) {
        // Save user data in localStorage
        localStorage.setItem("user", JSON.stringify(result));
  
        // Redirect to the main page
        window.location.href = "web.html";
      } else {
        alert(result.error || "Signup failed. Please try again.");
      }
    } catch (error) {
      console.error("Error during signup:", error);
      alert("An error occurred. Please try again later.");
    }
  });
  