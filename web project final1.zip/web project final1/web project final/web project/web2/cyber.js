document.addEventListener("DOMContentLoaded", function() {
    // Create and append the header with navigation
    const header = document.createElement('header');
    const nav = document.createElement('nav');
    
    const navLinks = [
        { href: "web.html", text: "Home" },
        { href: "contactus.html", text: "Contact Us" },
        { href: "aboutus.html", text: "About Us" },
        { href: "c++.html", text: "C++" },
        { href: "java.html", text: "Java" },
        { href: "data-science.html", text: "Data Science" },
        { href: "python.html", text: "Python" },
        { href: "app.html", text: "App Development" },
        { href: "web1.html", text: "Web Development" }
    ];
    
    navLinks.forEach(link => {
        const a = document.createElement('a');
        a.href = link.href;
        a.textContent = link.text;
        nav.appendChild(a);
    });
    
    header.appendChild(nav);
    document.body.insertBefore(header, document.body.firstChild); // Insert header before the main content

    // Create and append the main content
    const main = document.createElement('main');
    main.id = "content";  // Ensure the main content has the correct ID
    const mainHeading = document.createElement('h1');
    mainHeading.textContent = "Cyber Security Topics";
    main.appendChild(mainHeading);

    const gridContainer = document.createElement('div');
    gridContainer.className = "grid-container";
    
    const topics = [
        { class: "topic1", href: "cyber_security_intro.html", text: "Introduction to Cybersecurity" },
        { class: "topic2", href: "cyber_net.html", text: "Network Security" },
        { class: "topic3", href: "cyber_encrypt.html", text: "Encryption Techniques" },
        { class: "topic4", href: "cyber_encrypt.html", text: "Ethical Hacking" },
        { class: "topic5", href: "cyber_fire.html", text: "Firewalls" },
        { class: "topic6", href: "cyber_vulnere.html", text: "Vulnerabilities" },
        { class: "topic7", href: "cyber_mal.html", text: "Malware" },
        { class: "topic8", href: "cyber_cloud.html", text: "Cloud Security" }
    ];
    
    topics.forEach(topic => {
        const gridItem = document.createElement('div');
        gridItem.className = `grid-item ${topic.class}`;
        
        const link = document.createElement('a');
        link.href = topic.href;
        link.textContent = topic.text;
        
        gridItem.appendChild(link);
        gridContainer.appendChild(gridItem);
    });
    
    main.appendChild(gridContainer);

    // Create and append the references section
    const references = document.createElement('div');
    references.className = "references";
    
    const referencesHeading = document.createElement('h3');
    referencesHeading.textContent = "References";
    references.appendChild(referencesHeading);
    
    const table = document.createElement('table');
    
    const resources = [
        { resource: "OWASP", link: "https://owasp.org/" },
        { resource: "NIST Cybersecurity", link: "https://www.nist.gov/cyberframework" },
        { resource: "Cyber Security Tutorials", link: "https://www.cybrary.it/" }
    ];
    
    resources.forEach(resource => {
        const row = document.createElement('tr');
        
        const resourceCell = document.createElement('td');
        resourceCell.textContent = resource.resource;
        row.appendChild(resourceCell);
        
        const linkCell = document.createElement('td');
        const a = document.createElement('a');
        a.href = resource.link;
        a.textContent = resource.link;
        linkCell.appendChild(a);
        row.appendChild(linkCell);
        
        table.appendChild(row);
    });
    
    references.appendChild(table);
    main.appendChild(references);

    // Append the main content to the body
    document.body.appendChild(main);

    // Apply CSS to remove gap between header and main content
    const style = document.createElement('style');
    style.textContent = `
        header {
            margin: 0;
            padding: 10px 0; /* Adjust padding as needed */
        }
        main {
            margin: 0; /* Remove any margin above the main content */
            padding: 20px 0; /* Adjust padding to control spacing */
        }
        h1 {
            margin-top: 10px; /* Reduce the space above the heading */
        }
    `;
    document.head.appendChild(style);
});
